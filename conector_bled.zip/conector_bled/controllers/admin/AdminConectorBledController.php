<?php

class AdminConectorBledController extends ModuleAdminController {

}
?>